Revision: 2023-09-25

This file is provided for authors preparing ION conference papers.